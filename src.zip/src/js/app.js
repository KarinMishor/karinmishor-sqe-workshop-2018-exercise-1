import $ from 'jquery';
import {parseCode} from './code-analyzer';
let dataForTable=[];
let line=1;
let table;

$(document).ready(function () {
    $('#codeSubmissionButton').click(() => {
        let codeToParse = $('#codePlaceholder').val();
        let parsedCode = parseCode(codeToParse);
        $('#parsedCode').val(JSON.stringify(parsedCode, null, 2));
        dataForTable=[];
        FunctionDeclaration(parsedCode);
        for(let i=0;i<(parsedCode.body)[0].body.body.length; i++) {
            findType((parsedCode.body)[0].body.body[i]);
            table = document.getElementById('table');
        }

    });
});
function addToTable() {
    for(let i=0;i<dataForTable.length;i++){
        var row = table.insertRow(i+1);
        var line = row.insertCell(0);
        var type = row.insertCell(1);
        var name = row.insertCell(2);
        var condition = row.insertCell(3);
        var value = row.insertCell(4);
        line.innerHTML = dataForTable[i].Line;
        type.innerHTML = dataForTable[i].Type;
        name.innerHTML = dataForTable[i].Name;
        condition.innerHTML = dataForTable[i].Condition;
        value.innerHTML = dataForTable[i].Value;
    }
}
function pushLineToQ (line,type,name,condition,value){
    dataForTable.push({ 'line': line, 'type': type, 'name': name, 'condition' : condition, 'value': value} )  ;
}

function findType(parsedObj) {
    let type=parsedObj.type;
    if(type==('VariableDeclaration'))
        VariableDeclaration(parsedObj);
    else if(type==('ExpressionStatement'))
        ExpressionStatement(parsedObj);
    else if(type==('WhileStatement'))
        WhileStatement(parsedObj);
    else if(type==('ForStatement'))
        forStatement(parsedObj);
    else if(type==('IfStatement'))
        IfStatement(parsedObj);
    else if(type==('ReturnStatement'))
        ReturnStatement(parsedObj);
}
function FunctionDeclaration (parsedCode){
    let funName = (parsedCode.body)[0].id.name;
    pushLineToQ(line,'function declaration',funName,' ',' ');
    for(let i=0;i<(parsedCode.body)[0].params.length; i++)
    { //if there are params
        let param=(parsedCode.body)[0].params[i];
        pushLineToQ(line,'variable declaration' , param.name, ' ',' ');
    }
    line++;
}

function ReturnStatement(parsedObj){
    let val =  parseExpression(parsedObj.argument);
    pushLineToQ(line,'return statement' , '', '',val);
    line++;
}

function IfStatement(parsedObj){
    let condition=  parseExpression(parsedObj.test);
    pushLineToQ(line,'if statement','',condition,'');
    line++;
    let body =parsedObj.consequent;
    findType((body));
    if(parsedObj.alternate){
        if(parsedObj.alternate.type=='IfStatement'){
            elseIfStatement(parsedObj.alternate);
            /*else*/ if(parsedObj.alternate.type!='IfStatement') elseStatement(parsedObj.alternate);
        }
    }

}
function elseIfStatement(parsedObj) {
    let condition=  parseExpression(parsedObj.test);
    pushLineToQ(line,'else if statement','',condition,'');
    line++;
    let body =parsedObj.consequent;
    findType((body));
    if(parsedObj.alternate.type=='IfStatement')
        elseIfStatement(parsedObj.alternate);
        /*else*/ if(parsedObj.alternate.type!='IfStatement') elseStatement(parsedObj.alternate);
}

function elseStatement(parsedObj) {
    pushLineToQ(line,'else statement','','','');
    line++;
    findType((parsedObj));
}

function forStatement(parsedObj) {
    let part1,part2,part3;
    if (parsedObj.init.type == 'AssignmentExpression') {
        let name = parsedObj.init.left.name;
        let right = parsedObj.init.right;
        right = parseExpression(right);
        part1 = name+''+parsedObj.init.operator+''+right;
    }
    else if (parsedObj.init.type == 'VariableDeclaration') {
        let name = parsedObj.init.declarations[0].id.name;
        let right = parsedObj.init.declarations[0].init;
        right = parseExpression(right);
        part1 = name + '=' + right;
    }
    part2= parseExpression(parsedObj.test);
    if(parsedObj.update.type=='UpdateExpression'){
        let name = parsedObj.update.argument.name;
        let op = parsedObj.update.operator;
        part3=name+''+op;
    }
    else if(parsedObj.update.type=='AssignmentExpression'){
        let name = parsedObj.update.left.name;
        let right = parsedObj.update.right;
        right = parseExpression(right);
        part3=name+''+parsedObj.update.operator+''+right;
    }
    let condition=part1+';'+part2+';'+part3;
    pushLineToQ(line,'for statement','',condition,'');
    for (let i = 0; i < parsedObj.body.body.length; i++) {
        findType(parsedObj.body.body[i]);
    }
}
function WhileStatement(parsedObj) {
    let condition = parseExpression(parsedObj.test);
    pushLineToQ(line, 'while statement', '', condition, '');
    line++;
    for (let i = 0; i < parsedObj.body.body.length; i++) {
        findType(parsedObj.body.body[i]);
    }
}
function VariableDeclaration (parsedObj){
    for(let i=0;i<parsedObj.declarations.length; i++) {
        let VC = parsedObj.declarations[i];
        pushLineToQ(line, 'variable declaration', VC.id.name,'',VC.init);
    }
    line++;
}

function ExpressionStatement (parsedObj){
    if(parsedObj.expression.type=='AssignmentExpression') {
        let name = parsedObj.expression.left.name;
        let right = parsedObj.expression.right;
        right = parseExpression(right);
        pushLineToQ(line,'assignment expression',name,'',right);
    }
    else if(parsedObj.expression.type=='UpdateExpression') {
        let name = parsedObj.expression.argument.name;
        let op = parsedObj.expression.operator;
        pushLineToQ(line,'update expression',name,'',name+''+op);
    }
    line++;
}

function parseExpression(exp) {
    if (exp.type == ('BinaryExpression'))
        return parseBinary(exp);
    else {
        return simpleExpression(exp);
    }
}
function simpleExpression(exp){
    if(exp.type=='Identifier') {
        return exp.name;
    }
    else if(exp.type=='Literal') {
        return exp.value;
    }
    else if(exp.type=='UnaryExpression')
        return exp.operator+''+exp.argument.value;

    else if(exp.type=='MemberExpression') {
        return exp.object.name + '[' + parseExpression(exp.property) + ']';
    }
}

function parseBinary(binary) {
    let leftExp = binary.left;
    if (leftExp.type == ('BinaryExpression'))
        leftExp = '(' + parseBinary(leftExp)+')';
    else {
        leftExp = simpleExpression(leftExp);
    }
    let rigthExp = binary.right;
    if (rigthExp.type == ('BinaryExpression'))
        rigthExp = '(' + parseBinary(rigthExp)+')';
    else {
        rigthExp = simpleExpression(rigthExp);
    }
    return leftExp + '' + binary.operator + '' + rigthExp;
}

